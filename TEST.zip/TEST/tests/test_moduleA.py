import pytest
import mypackage.moduleA as A


def test_a():
    assert 'a' == A.do_a()


def test_a1():
    assert 'Positive' == A.do_a1(7)


def test_a1_negative():
    with pytest.raises(Exception) as e:
        A.do_a1(-9)
