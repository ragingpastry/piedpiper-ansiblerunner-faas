def do_a():
    return 'a'


def do_a1(i):
    if i < 0:
        raise ValueError('Negative')
    else:
        return 'Positive'


if __name__ == '__main__':
    do_a()
    do_a1(7)
    do_a1(-7)
